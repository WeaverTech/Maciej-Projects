# Kawasaki Palletizer 2.3
Kompletny projekt. Nie wymaga wcześniejszych aktualizacji.

## Uruchomienie w VS Code
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:PYTHONPATH = "src"
python run.py
```

## Najważniejsze zmiany 2.3
- walidacja odświeża się po wejściu w zakładkę Walidacja; brak przycisku na górnym pasku,
- nowa graficzna miarka: P1/P2, linia i wynik na planszy,
- sterowanie miarką stale widoczne w pasku stanu,
- tryb pojedynczy automatycznie wyłącza pola sekcji 2 i cykli,
- narożniki A/B/C/D oraz aktywny BASE są stale widoczne,
- graficzny wybór kierunków +X i +Y,
- natychmiastowy podgląd osi podczas zmiany ustawień,
- uproszczony górny pasek i menu Narzędzia,
- pasek stanu z warstwą, liczbą produktów i walidacją,
- generator otwiera się w dużym oknie,
- walidator AS, porównanie A/B, diagnostyka i logowanie błędów.
