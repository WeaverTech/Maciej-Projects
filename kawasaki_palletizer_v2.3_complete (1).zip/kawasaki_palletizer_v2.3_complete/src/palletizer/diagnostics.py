import logging,sys,traceback,platform
from pathlib import Path
LOG=Path.home()/".kawasaki_palletizer"/"logs";LOG.mkdir(parents=True,exist_ok=True);LOG_FILE=LOG/"app.log";logging.basicConfig(filename=LOG_FILE,level=logging.INFO,encoding="utf-8")
def install(show):
 def hook(t,v,tb):
  text="".join(traceback.format_exception(t,v,tb));logging.error(text);show(text,str(LOG_FILE))
 sys.excepthook=hook
def info():
 import PySide6
 return f"Kawasaki Palletizer 2.3\nPython {platform.python_version()}\nPySide6 {PySide6.__version__}\n{platform.platform()}\nLog: {LOG_FILE}"
