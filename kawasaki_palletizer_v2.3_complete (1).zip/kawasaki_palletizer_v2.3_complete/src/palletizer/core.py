from __future__ import annotations
import re
from .models import *
EPS=1e-6
VECTORS={"prawo":(1,0),"lewo":(-1,0),"dol":(0,1),"gora":(0,-1)}
def origin(p):
 P=p.pallet
 return {Corner.A:(0,0),Corner.B:(P.length,0),Corner.C:(P.length,P.width),Corner.D:(0,P.width)}[P.base_corner]
def transform(x,y,p):
 ox,oy=origin(p);vx=VECTORS[p.pallet.x_direction];vy=VECTORS[p.pallet.y_direction];dx,dy=x-ox,y-oy
 return dx*vx[0]+dy*vx[1],dx*vy[0]+dy*vy[1]
def axes_valid(p):
 vx=VECTORS[p.pallet.x_direction];vy=VECTORS[p.pallet.y_direction];return vx[0]*vy[0]+vx[1]*vy[1]==0
def rotate_b(p):p.layers["B"]=Layer("B",[Placement(i.id,p.pallet.length-i.x,p.pallet.width-i.y,(i.rotation+180)%360,i.order) for i in p.layers["A"].items]);p.sequence=["A","B"]*max(1,p.robot.layers//2)+(["A"] if p.robot.layers%2 else [])
def generate(p,count,rotation=0):
 w,h=p.product.footprint(rotation);cols=max(1,int(p.pallet.length//max(1,w)));p.layers["A"].items=[Placement(i+1,w/2+(i%cols)*w,h/2+(i//cols)*h,rotation,i+1) for i in range(count)]
def validate_geometry(p,name="A"):
 out=[];items=p.layers[name].items
 for x in items:
  w,h=p.product.footprint(x.rotation);over=max(0,w/2-x.x,x.x+w/2-p.pallet.length,h/2-x.y,x.y+h/2-p.pallet.width)
  if over>EPS:out.append(("Ostrzeżenie" if p.product.kind==Kind.BAG and p.product.allow_overhang and over<=p.product.max_overhang else "Błąd",f"Produkt {x.order} wystaje {over:.2f} mm",[x.id]))
 for n,a in enumerate(items):
  aw,ah=p.product.footprint(a.rotation)
  for b in items[n+1:]:
   bw,bh=p.product.footprint(b.rotation);ox=min(a.x+aw/2,b.x+bw/2)-max(a.x-aw/2,b.x-bw/2);oy=min(a.y+ah/2,b.y+bh/2)-max(a.y-ah/2,b.y-bh/2)
   if ox>EPS and oy>EPS:
    dep=min(ox,oy);ok=p.product.kind==Kind.BAG and p.product.allow_overlap and dep<=p.product.max_overlap;out.append(("Ostrzeżenie" if ok else "Błąd",f"Produkty {a.order}/{b.order} nakładają się {dep:.2f} mm",[a.id,b.id]))
 if not axes_valid(p):out.append(("Błąd","Osie X i Y nie są prostopadłe",[]))
 return out
def parse_cycles(raw,orders):
 if not raw.strip():return [],["Brak konfiguracji cykli"]
 valid=set(orders);seen={};cycles=[];errors=[]
 for ci,part in enumerate(raw.split(";"),1):
  c=[];sections=set()
  for token in part.split(","):
   if "=" not in token:errors.append(f"Cykl {ci}: wymagany format produkt=sekcja");continue
   a,b=[s.strip() for s in token.split("=",1)]
   if not a.isdigit() or not b.isdigit():errors.append(f"Cykl {ci}: błędne '{token}'");continue
   prod,sec=int(a),int(b)
   if prod not in valid:errors.append(f"Produkt {prod} nie istnieje");continue
   if sec not in (1,2):errors.append(f"Sekcja {sec} nie istnieje");continue
   if prod in seen:errors.append(f"Produkt {prod} występuje ponownie");continue
   if sec in sections:errors.append(f"Cykl {ci}: sekcja {sec} użyta dwa razy");continue
   seen[prod]=ci;sections.add(sec);c.append((prod,sec))
  if c:cycles.append(c)
 missing=sorted(valid-set(seen))
 if missing:errors.append("Nieprzypisane produkty: "+", ".join(map(str,missing)))
 return cycles,errors
def cycles(p):
 orders=[x.order for x in p.layers["A"].items]
 return ([[(o,1)] for o in orders],[]) if p.robot.pick_mode=="pojedynczy" else parse_cycles(p.robot.assignments,orders)
def compare_ab(p):
 if "B" not in p.layers:return [("Błąd","Brak warstwy B")]
 A={x.order:x for x in p.layers["A"].items};B={x.order:x for x in p.layers["B"].items};out=[]
 for n in sorted(set(A)|set(B)):
  if n not in A or n not in B:out.append(("Błąd",f"Produkt {n} nie występuje w obu warstwach"));continue
  a,b=A[n],B[n]
  if abs(b.x-(p.pallet.length-a.x))>EPS or abs(b.y-(p.pallet.width-a.y))>EPS:out.append(("Ostrzeżenie",f"Produkt {n}: pozycja B różni się od obrotu 180°"))
  if b.rotation%360!=(a.rotation+180)%360:out.append(("Ostrzeżenie",f"Produkt {n}: niezgodny obrót"))
 return out or [("Informacja","Warstwy A/B są zgodne")]
def render_as(p):
 cy,errs=cycles(p)
 if errs:raise ValueError("\n".join(errs))
 if not axes_valid(p):raise ValueError("Osie X/Y muszą być prostopadłe")
 R=p.robot;A=sorted(p.layers["A"].items,key=lambda x:x.order);on={1:R.s1_on,2:R.s2_on};off={1:R.s1_off,2:R.s2_off};lines=[f".PROGRAM {R.program_name}()","  SPEED 100 ALWAYS","  ACCEL 100 ALWAYS","  DECEL 100 ALWAYS",f"  .wyswarstwy = {p.product.layer_increment}",f"  .ilewarstw = {R.layers}"]
 for name in ("A","B"):
  if name in p.layers:
   lines.append(f"; WARSTWA {name}")
   for x in sorted(p.layers[name].items,key=lambda q:q.order):a,b=transform(x.x,x.y,p);lines.append(f"  POINT w{name.lower()}_cel[{x.order}] = {R.base_name}+TRANS({a:.3f},{b:.3f},{R.first_z:.3f},{x.rotation},0,0)")
 lines += ["  FOR .j = 1 TO .ilewarstw","    .z_offset = (.j-1)*.wyswarstwy",f"    .z_safe = {R.safe_z}+.z_offset"]
 if "B" in p.layers:
  lines.append("    IF (.j MOD 2)==1 THEN")
  for x in A:lines.append(f"      POINT cel[{x.order}] = wa_cel[{x.order}]")
  lines.append("    ELSE")
  for x in sorted(p.layers["B"].items,key=lambda q:q.order):lines.append(f"      POINT cel[{x.order}] = wb_cel[{x.order}]")
  lines.append("    END")
 else:
  for x in A:lines.append(f"    POINT cel[{x.order}] = wa_cel[{x.order}]")
 for ci,c in enumerate(cy,1):
  lines += [f"; CYKL {ci}",f"    JMOVE {R.pickup_approach}",f"    LMOVE {R.pickup}"]
  for _,s in c:lines.append(f"    SIGNAL {on[s]}")
  lines += [f"    TWAIT {R.grip_wait}",f"    LMOVE {R.pickup_approach}"]
  for prod,s in c:lines += [f"    JMOVE SHIFT(cel[{prod}] BY 0,0,.z_safe)",f"    LMOVE SHIFT(cel[{prod}] BY 0,0,.z_offset)",f"    SIGNAL {off[s]}",f"    TWAIT {R.release_wait}",f"    LMOVE SHIFT(cel[{prod}] BY 0,0,.z_safe)"]
 lines += ["  END",".END",""];return "\n".join(lines)
def validate_as(code):
 stack=[];issues=[]
 for n,line in enumerate(code.splitlines(),1):
  s=line.strip().upper()
  if s.startswith("FOR ") or s.startswith("IF "):stack.append((s.split()[0],n))
  elif s=="END":
   if stack:stack.pop()
   else:issues.append(("Błąd","END bez bloku",n))
  if s.startswith("SIGNAL") and not re.search(r"SIGNAL\s+[-+]?\d",s):issues.append(("Błąd","Błędny SIGNAL",n))
 for k,n in stack:issues.append(("Błąd",f"{k} bez END",n))
 return issues
