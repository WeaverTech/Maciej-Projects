from __future__ import annotations
from pathlib import Path
import math
from PySide6.QtCore import Qt,QPointF,QTimer,Signal
from PySide6.QtGui import QAction,QBrush,QColor,QCursor,QFont,QKeyEvent,QMouseEvent,QPainter,QPen,QPolygonF
from PySide6.QtWidgets import *
from .models import *
from .core import *
from .diagnostics import info
class Item(QGraphicsRectItem):
 def __init__(self,p,w,h,s,view):
  super().__init__(-w*s/2,-h*s/2,w*s,h*s);self.p=p;self.w=w;self.h=h;self.s=s;self.view=view;self.setPos(p.x*s,p.y*s);self.setFlags(QGraphicsItem.GraphicsItemFlag.ItemIsMovable|QGraphicsItem.GraphicsItemFlag.ItemIsSelectable|QGraphicsItem.GraphicsItemFlag.ItemSendsGeometryChanges);self.setBrush(QBrush(QColor("#7dd3fc")));self.setPen(QPen(QColor("#075985"),2));t=QGraphicsSimpleTextItem(str(p.order),self);f=QFont();f.setPointSize(20);f.setBold(True);t.setFont(f);b=t.boundingRect();t.setPos(-b.width()/2,-b.height()/2)
 def itemChange(self,c,v):
  if c==QGraphicsItem.GraphicsItemChange.ItemPositionChange and self.scene() and isinstance(v,QPointF):x,y=self.view.snap(v.x()/self.s,v.y()/self.s,self.w,self.h);return QPointF(x*self.s,y*self.s)
  if c==QGraphicsItem.GraphicsItemChange.ItemPositionHasChanged:self.p.x,self.p.y=self.pos().x()/self.s,self.pos().y()/self.s;self.view.changed.emit()
  return super().itemChange(c,v)
class View(QGraphicsView):
 selected=Signal(object);changed=Signal();mouse_mm=Signal(float,float);measure_help=Signal(str)
 def __init__(self):
  super().__init__();self.project=None;self.name="A";self.s=.65;self.step=50;self.grid=True;self.snap_on=True;self.measure_mode=False;self.measure_points=[];self.measure_items=[];self.setMouseTracking(True);self.setRenderHint(QPainter.RenderHint.Antialiasing);self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
 def snap(self,x,y,w,h):
  if not self.snap_on:return x,y
  for c in (w/2,self.project.pallet.length-w/2):
   if abs(x-c)<=18:x=c
  for c in (h/2,self.project.pallet.width-h/2):
   if abs(y-c)<=18:y=c
  for o in self.project.layers[self.name].items:
   if abs(x-o.x)<=10:x=o.x
   if abs(y-o.y)<=10:y=o.y
  if self.grid:x=round(x/self.step)*self.step;y=round(y/self.step)*self.step
  return x,y
 def snap_measure(self,x,y):
  candidates=[(0,0),(self.project.pallet.length,0),(self.project.pallet.length,self.project.pallet.width),(0,self.project.pallet.width)]
  for p in self.project.layers[self.name].items:
   w,h=self.project.product.footprint(p.rotation);candidates += [(p.x,p.y),(p.x-w/2,p.y-h/2),(p.x+w/2,p.y-h/2),(p.x+w/2,p.y+h/2),(p.x-w/2,p.y+h/2)]
  best=min(candidates,key=lambda q:math.hypot(q[0]-x,q[1]-y))
  return best if math.hypot(best[0]-x,best[1]-y)<=20 else (x,y)
 def start_measure(self):self.measure_mode=True;self.measure_points=[];self.clear_measure();self.setCursor(Qt.CursorShape.CrossCursor);self.measure_help.emit("Miarka: LPM - wybierz P1 | LPM ponownie - wybierz P2 | Esc - anuluj | PPM - wyczyść pomiar")
 def stop_measure(self):self.measure_mode=False;self.unsetCursor();self.measure_help.emit("")
 def clear_measure(self):
  if self.scene():
   for i in self.measure_items:
    if i.scene():self.scene().removeItem(i)
  self.measure_items=[];self.measure_points=[]
 def mousePressEvent(self,e):
  if self.measure_mode:
   if e.button()==Qt.MouseButton.RightButton:self.clear_measure();self.measure_help.emit("Miarka: pomiar wyczyszczony. LPM - wybierz P1 | Esc - anuluj");return
   if e.button()==Qt.MouseButton.LeftButton:
    q=self.mapToScene(e.position().toPoint());x,y=self.snap_measure(q.x()/self.s,q.y()/self.s);self.measure_points.append((x,y));self.draw_measure()
    if len(self.measure_points)==1:self.measure_help.emit(f"Miarka: P1=({x:.1f}, {y:.1f}) mm | LPM - wybierz P2 | Esc - anuluj | PPM - wyczyść")
    elif len(self.measure_points)==2:
     a,b=self.measure_points;dx=b[0]-a[0];dy=b[1]-a[1];self.measure_help.emit(f"Pomiar: ΔX={dx:.1f} mm | ΔY={dy:.1f} mm | L={math.hypot(dx,dy):.1f} mm | PPM - wyczyść | Esc - zakończ")
    return
  super().mousePressEvent(e)
 def keyPressEvent(self,e):
  if self.measure_mode and e.key()==Qt.Key.Key_Escape:self.clear_measure();self.stop_measure();return
  super().keyPressEvent(e)
 def mouseMoveEvent(self,e):
  q=self.mapToScene(e.position().toPoint());self.mouse_mm.emit(q.x()/self.s,q.y()/self.s);super().mouseMoveEvent(e)
 def draw_measure(self):
  self.clear_measure_visual_only();sc=self.scene();pen=QPen(QColor("#0a84ff"),2,Qt.PenStyle.DashLine)
  for n,(x,y) in enumerate(self.measure_points,1):
   dot=sc.addEllipse(x*self.s-5,y*self.s-5,10,10,QPen(QColor("#0a84ff"),2),QBrush(QColor("white")));txt=sc.addSimpleText(f"P{n}");txt.setBrush(QBrush(QColor("#0a84ff")));txt.setPos(x*self.s+7,y*self.s-22);self.measure_items += [dot,txt]
  if len(self.measure_points)==2:
   a,b=self.measure_points;line=sc.addLine(a[0]*self.s,a[1]*self.s,b[0]*self.s,b[1]*self.s,pen);dx=b[0]-a[0];dy=b[1]-a[1];txt=sc.addSimpleText(f"ΔX {dx:.1f} | ΔY {dy:.1f} | L {math.hypot(dx,dy):.1f} mm");txt.setBrush(QBrush(QColor("#0a84ff")));txt.setPos((a[0]+b[0])/2*self.s,(a[1]+b[1])/2*self.s-24);self.measure_items += [line,txt]
 def clear_measure_visual_only(self):
  if self.scene():
   for i in self.measure_items:
    if i.scene():self.scene().removeItem(i)
  self.measure_items=[]
 def redraw(self):
  if not self.project:return
  p=self.project.pallet;s=self.s;sc=QGraphicsScene(self);sc.addRect(0,0,p.length*s,p.width*s,QPen(QColor("#334155"),3),QBrush(QColor("white")))
  if self.grid:
   x=self.step
   while x<p.length:sc.addLine(x*s,0,x*s,p.width*s,QPen(QColor("#e5e7eb")));x+=self.step
   y=self.step
   while y<p.width:sc.addLine(0,y*s,p.length*s,y*s,QPen(QColor("#e5e7eb")));y+=self.step
  corners={"A":(0,0),"B":(p.length*s,0),"C":(p.length*s,p.width*s),"D":(0,p.width*s)}
  for name,(x,y) in corners.items():
   t=sc.addSimpleText(name+("  BASE" if name==p.base_corner.value else ""));f=QFont();f.setPointSize(15 if name==p.base_corner.value else 12);f.setBold(True);t.setFont(f);t.setBrush(QBrush(QColor("#0a84ff" if name==p.base_corner.value else "#667085")));t.setPos(x+(-38 if x==0 else 8),y+(-30 if y==0 else 6))
  ox,oy=origin(self.project);vx=VECTORS[p.x_direction];vy=VECTORS[p.y_direction]
  sc.addLine(ox*s,oy*s,(ox+vx[0]*100)*s,(oy+vx[1]*100)*s,QPen(QColor("#ef4444"),3));sc.addLine(ox*s,oy*s,(ox+vy[0]*100)*s,(oy+vy[1]*100)*s,QPen(QColor("#2563eb"),3))
  xt=sc.addSimpleText("+X");xt.setBrush(QBrush(QColor("#ef4444")));xt.setPos((ox+vx[0]*100)*s,(oy+vx[1]*100)*s);yt=sc.addSimpleText("+Y");yt.setBrush(QBrush(QColor("#2563eb")));yt.setPos((ox+vy[0]*100)*s,(oy+vy[1]*100)*s)
  issues=validate_geometry(self.project,self.name);bad={i for sev,msg,ids in issues if sev=="Błąd" for i in ids};warn={i for sev,msg,ids in issues if sev=="Ostrzeżenie" for i in ids}
  for p in self.project.layers[self.name].items:
   w,h=self.project.product.footprint(p.rotation);it=Item(p,w,h,s,self);it.setBrush(QBrush(QColor("#fca5a5" if p.id in bad else "#fdba74" if p.id in warn else "#7dd3fc")));sc.addItem(it)
  sc.selectionChanged.connect(lambda:self.selected.emit(sc.selectedItems()[0].p if sc.selectedItems() and isinstance(sc.selectedItems()[0],Item) else None));self.setScene(sc);self.measure_items=[]
class MainWindow(QMainWindow):
 def __init__(self):
  super().__init__();self.p=Project();self.name="A";self.current=None;self.path=None;self.validation_timer=QTimer(self);self.validation_timer.setSingleShot(True);self.validation_timer.setInterval(120);self.validation_timer.timeout.connect(self.validate_live);self.setWindowTitle("Kawasaki Palletizer 2.3");self.resize(1550,920);self.build();self.refresh()
 def spin(self,v=0,mi=-100000,ma=100000):w=QDoubleSpinBox();w.setRange(mi,ma);w.setValue(v);w.setSuffix(" mm");return w
 def build(self):
  root=QWidget();self.setCentralWidget(root);l=QVBoxLayout(root);self.banner=QLabel();self.banner.setAlignment(Qt.AlignmentFlag.AlignCenter);self.banner.setStyleSheet("font-size:20px;font-weight:700;padding:10px;background:#dbeafe;border-radius:10px");l.addWidget(self.banner);bar=QHBoxLayout()
  for t,f in (("Dodaj",self.add),("Obróć",self.rotate),("Usuń",self.delete),("Warstwa B",self.make_b),("Generator",self.generator),("Podgląd AS",self.preview)):b=QPushButton(t);b.clicked.connect(f);bar.addWidget(b)
  bar.addStretch();tools=QToolButton();tools.setText("Narzędzia");tools.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup);menu=QMenu(tools)
  for t,f in (("Miarka",self.measure),("Sprawdź punkt",self.test_point),("Porównaj A/B",self.compare),("Edytor cykli",self.cycle_dialog)):a=menu.addAction(t);a.triggered.connect(f)
  tools.setMenu(menu);bar.addWidget(tools);l.addLayout(bar);s=QSplitter();l.addWidget(s,1);self.tabs=QTabWidget();self.tabs.setMinimumWidth(410);self.tabs.currentChanged.connect(self.tab_changed);s.addWidget(self.tabs);self.settings();center=QWidget();cl=QVBoxLayout(center);self.layer=QComboBox();self.layer.currentTextChanged.connect(self.change_layer);cl.addWidget(self.layer);self.view=View();self.view.project=self.p;self.view.selected.connect(self.select);self.view.changed.connect(lambda:self.validation_timer.start());self.view.mouse_mm.connect(self.cursor_status);self.view.measure_help.connect(self.measure_status);cl.addWidget(self.view,1);s.addWidget(center)
  self.status=QStatusBar();self.setStatusBar(self.status);self.status_label=QLabel("Gotowy");self.status.addWidget(self.status_label,1)
  m=self.menuBar().addMenu("Plik")
  for t,f in (("Nowy",self.new),("Otwórz",self.open),("Zapisz",self.save),("Zapisz jako",self.save_as)):a=QAction(t,self);a.triggered.connect(f);m.addAction(a)
  e=self.menuBar().addMenu("Edycja");a=e.addAction("Wyczyść warstwę");a.triggered.connect(self.clear)
  h=self.menuBar().addMenu("Pomoc");a=h.addAction("Diagnostyka");a.triggered.connect(self.diag)
 def settings(self):
  page=QWidget();f=QFormLayout(page);self.pl=self.spin(1200,1);self.pw=self.spin(800,1);self.corner=QComboBox();self.corner.addItems(list("ABCD"));self.xdir=QComboBox();self.xdir.addItem("Prawo","prawo");self.xdir.addItem("Lewo","lewo");self.xdir.addItem("Góra","gora");self.xdir.addItem("Dół","dol");self.ydir=QComboBox();self.ydir.addItem("Prawo","prawo");self.ydir.addItem("Lewo","lewo");self.ydir.addItem("Góra","gora");self.ydir.addItem("Dół","dol")
  for a,w in (("Długość",self.pl),("Szerokość",self.pw),("Narożnik BASE",self.corner),("Kierunek +X",self.xdir),("Kierunek +Y",self.ydir)):f.addRow(a,w)
  self.corner.currentTextChanged.connect(self.preview_axes);self.xdir.currentIndexChanged.connect(self.preview_axes);self.ydir.currentIndexChanged.connect(self.preview_axes);b=QPushButton("Zastosuj paletę i osie");b.clicked.connect(self.apply_pallet);f.addRow(b);self.tabs.addTab(page,"Paleta")
  page=QWidget();f=QFormLayout(page);self.kind=QComboBox();self.kind.addItems(["worek","karton"]);self.ql=self.spin(600,1);self.qw=self.spin(400,1);self.qh=self.spin(100,1);self.over=QCheckBox("Zezwalaj na wystawanie");self.over.setChecked(True);self.ov=QCheckBox("Zezwalaj na nakładanie");self.ov.setChecked(True)
  for a,w in (("Typ",self.kind),("Długość",self.ql),("Szerokość",self.qw),("Wysokość",self.qh),("",self.over),("",self.ov)):f.addRow(a,w)
  b=QPushButton("Zastosuj produkt");b.clicked.connect(self.apply_product);f.addRow(b);self.tabs.addTab(page,"Produkt")
  page=QWidget();f=QFormLayout(page);self.mode=QComboBox();self.mode.addItems(["Pojedynczy","Podwójny"]);self.s1on=QLineEdit();self.s1off=QLineEdit();self.s2on=QLineEdit();self.s2off=QLineEdit();self.assign=QLineEdit();self.base=QLineEdit();self.pick=QLineEdit();self.pickapp=QLineEdit();self.layers=QSpinBox();self.layers.setRange(1,100)
  for a,w in (("Tryb",self.mode),("Sekcja 1 ON",self.s1on),("Sekcja 1 OFF",self.s1off),("Sekcja 2 ON",self.s2on),("Sekcja 2 OFF",self.s2off),("Cykle",self.assign),("BASE",self.base),("Pobranie",self.pick),("Najazd",self.pickapp),("Warstwy",self.layers)):f.addRow(a,w)
  self.mode.currentIndexChanged.connect(self.update_robot_mode);b=QPushButton("Zastosuj Robot AS");b.clicked.connect(self.apply_robot);f.addRow(b);self.tabs.addTab(page,"Robot AS")
  page=QWidget();f=QFormLayout(page);self.sel=QLabel("Brak");self.sx=self.spin();self.sy=self.spin();self.srot=QComboBox();self.srot.addItems(["0","90","180","270"])
  for a,w in (("Produkt",self.sel),("X",self.sx),("Y",self.sy),("Obrót",self.srot)):f.addRow(a,w)
  b=QPushButton("Zastosuj");b.clicked.connect(self.apply_selected);f.addRow(b);self.tabs.addTab(page,"Zaznaczony")
  self.validation_page=QWidget();v=QVBoxLayout(self.validation_page);self.validation_summary=QLabel();self.validation_summary.setStyleSheet("font-size:16px;font-weight:700;padding:10px");self.issues=QListWidget();v.addWidget(self.validation_summary);v.addWidget(self.issues);self.tabs.addTab(self.validation_page,"Walidacja")
 def update_robot_mode(self):
  enabled=self.mode.currentIndex()==1
  for w in (self.s2on,self.s2off,self.assign):w.setEnabled(enabled)
 def tab_changed(self,index):
  if self.tabs.widget(index) is self.validation_page:self.validate_live()
 def refresh(self):
  p=self.p;r=p.robot;self.banner.setText(f"AKTYWNA WARSTWA: {self.name}");self.layer.blockSignals(True);self.layer.clear();self.layer.addItems(p.layers);self.layer.setCurrentText(self.name);self.layer.blockSignals(False);self.pl.setValue(p.pallet.length);self.pw.setValue(p.pallet.width);self.corner.setCurrentText(p.pallet.base_corner.value);self.xdir.setCurrentIndex(self.xdir.findData(p.pallet.x_direction));self.ydir.setCurrentIndex(self.ydir.findData(p.pallet.y_direction));self.kind.setCurrentText(p.product.kind.value);self.ql.setValue(p.product.length);self.qw.setValue(p.product.width);self.qh.setValue(p.product.height);self.over.setChecked(p.product.allow_overhang);self.ov.setChecked(p.product.allow_overlap);self.mode.setCurrentIndex(0 if r.pick_mode=="pojedynczy" else 1);self.s1on.setText(r.s1_on);self.s1off.setText(r.s1_off);self.s2on.setText(r.s2_on);self.s2off.setText(r.s2_off);self.assign.setText(r.assignments);self.base.setText(r.base_name);self.pick.setText(r.pickup);self.pickapp.setText(r.pickup_approach);self.layers.setValue(r.layers);self.update_robot_mode();self.view.project=p;self.view.name=self.name;self.view.redraw();self.validate_live();self.update_status()
 def selected_items(self):return [i for i in (self.view.scene().selectedItems() if self.view.scene() else []) if isinstance(i,Item)]
 def add(self):a=self.p.layers[self.name].items;i=max([x.id for x in a],default=0)+1;a.append(Placement(i,self.p.pallet.length/2,self.p.pallet.width/2,0,len(a)+1));self.refresh()
 def rotate(self):
  for i in self.selected_items():i.p.rotation=(i.p.rotation+90)%360
  self.refresh()
 def delete(self):
  a=self.p.layers[self.name].items
  for i in self.selected_items():
   if i.p in a:a.remove(i.p)
  self.refresh()
 def clear(self):
  if QMessageBox.question(self,"Wyczyść","Usunąć wszystkie produkty z aktywnej warstwy?")==QMessageBox.StandardButton.Yes:self.p.layers[self.name].items.clear();self.refresh()
 def make_b(self):rotate_b(self.p);self.name="B";self.refresh()
 def generator(self):
  d=QDialog(self);d.resize(820,620);d.setMinimumSize(720,520);d.setWindowTitle("Generator");l=QVBoxLayout(d);count=QSpinBox();count.setRange(1,100);count.setValue(6);rot=QComboBox();rot.addItems(["0","90"]);l.addWidget(QLabel("Liczba produktów"));l.addWidget(count);l.addWidget(QLabel("Obrót"));l.addWidget(rot);b=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);b.accepted.connect(d.accept);b.rejected.connect(d.reject);l.addWidget(b)
  if d.exec():generate(self.p,count.value(),int(rot.currentText()));self.name="A";self.refresh()
 def cycle_dialog(self):
  d=QDialog(self);d.resize(720,520);d.setWindowTitle("Edytor cykli");l=QVBoxLayout(d);t=QTableWidget(0,3);t.setHorizontalHeaderLabels(["Cykl","Produkt","Sekcja"]);l.addWidget(t);orders=[x.order for x in self.p.layers["A"].items];rows=[]
  for i in range(0,len(orders),2):rows.append((i//2+1,orders[i],1));rows += [(i//2+1,orders[i+1],2)] if i+1<len(orders) else []
  t.setRowCount(len(rows))
  for r,row in enumerate(rows):
   for c,val in enumerate(row):t.setItem(r,c,QTableWidgetItem(str(val)))
  b=QDialogButtonBox(QDialogButtonBox.StandardButton.Ok|QDialogButtonBox.StandardButton.Cancel);b.accepted.connect(d.accept);b.rejected.connect(d.reject);l.addWidget(b)
  if d.exec():
   g={}
   for r in range(t.rowCount()):g.setdefault(int(t.item(r,0).text()),[]).append(f"{int(t.item(r,1).text())}={int(t.item(r,2).text())}")
   self.p.robot.assignments=";".join(",".join(g[k]) for k in sorted(g));self.refresh()
 def compare(self):QMessageBox.information(self,"A/B","\n".join(f"{s}: {m}" for s,m in compare_ab(self.p)))
 def select(self,p):self.current=p;self.sel.setText(str(p.order) if p else "Brak");self.sx.setValue(p.x) if p else None;self.sy.setValue(p.y) if p else None;self.srot.setCurrentText(str(p.rotation)) if p else None
 def apply_selected(self):
  if self.current:self.current.x=self.sx.value();self.current.y=self.sy.value();self.current.rotation=int(self.srot.currentText());self.refresh()
 def test_point(self):
  if not self.current:return QMessageBox.information(self,"Punkt","Zaznacz produkt")
  x,y=transform(self.current.x,self.current.y,self.p);QMessageBox.information(self,"Transformacja",f"Plansza: {self.current.x:.3f}, {self.current.y:.3f}\nBASE {self.p.pallet.base_corner.value}: {x:.3f}, {y:.3f}\nOsie: +X {self.p.pallet.x_direction}, +Y {self.p.pallet.y_direction}\n\n{self.p.robot.base_name}+TRANS({x:.3f},{y:.3f},{self.p.robot.first_z:.3f},{self.current.rotation},0,0)")
 def measure(self):self.view.start_measure()
 def preview_axes(self):
  self.p.pallet.base_corner=Corner(self.corner.currentText());self.p.pallet.x_direction=self.xdir.currentData();self.p.pallet.y_direction=self.ydir.currentData();self.view.redraw()
 def apply_pallet(self):
  self.p.pallet.length=self.pl.value();self.p.pallet.width=self.pw.value();self.p.pallet.base_corner=Corner(self.corner.currentText());self.p.pallet.x_direction=self.xdir.currentData();self.p.pallet.y_direction=self.ydir.currentData()
  if not axes_valid(self.p):QMessageBox.warning(self,"Osie","Osie X i Y muszą być prostopadłe.")
  self.refresh()
 def apply_product(self):self.p.product.kind=Kind(self.kind.currentText());self.p.product.length=self.ql.value();self.p.product.width=self.qw.value();self.p.product.height=self.qh.value();self.p.product.allow_overhang=self.over.isChecked();self.p.product.allow_overlap=self.ov.isChecked();self.refresh()
 def apply_robot(self):r=self.p.robot;r.pick_mode="pojedynczy" if self.mode.currentIndex()==0 else "podwojny";r.s1_on=self.s1on.text();r.s1_off=self.s1off.text();r.s2_on=self.s2on.text();r.s2_off=self.s2off.text();r.assignments=self.assign.text();r.base_name=self.base.text();r.pickup=self.pick.text();r.pickup_approach=self.pickapp.text();r.layers=self.layers.value();self.refresh()
 def validate_live(self):
  self.issues.clear();items=validate_geometry(self.p,self.name);_,errs=cycles(self.p)
  for s,m,ids in items:self.issues.addItem(f"{s}: {m}")
  for e in errs:self.issues.addItem("Błąd: "+e)
  errors=sum(self.issues.item(i).text().startswith("Błąd:") for i in range(self.issues.count()));warnings=sum(self.issues.item(i).text().startswith("Ostrzeżenie:") for i in range(self.issues.count()));self.validation_summary.setText(f"{errors} błędów • {warnings} ostrzeżeń");self.update_status(errors,warnings)
 def preview(self):
  try:code=render_as(self.p)
  except Exception as e:return QMessageBox.critical(self,"Błąd",str(e))
  d=QDialog(self);d.resize(1000,760);l=QVBoxLayout(d);e=QPlainTextEdit(code);e.setLineWrapMode(e.LineWrapMode.NoWrap);l.addWidget(e);issues=validate_as(code);l.addWidget(QLabel("\n".join(f"{s}: {m} (linia {n})" for s,m,n in issues) or "Walidator AS: OK"));copy=QPushButton("Kopiuj kod");copy.clicked.connect(lambda:QApplication.clipboard().setText(e.toPlainText()));l.addWidget(copy);d.exec()
 def change_layer(self,n):
  if n in self.p.layers:self.name=n;self.refresh()
 def cursor_status(self,x,y):
  if not self.view.measure_mode:self.status_label.setText(f"Warstwa {self.name} | X: {x:.1f} mm | Y: {y:.1f} mm")
 def measure_status(self,text):self.status_label.setText(text or "Gotowy")
 def update_status(self,errors=None,warnings=None):
  if self.view.measure_mode:return
  if errors is None:
   errors=sum(self.issues.item(i).text().startswith("Błąd:") for i in range(self.issues.count()));warnings=sum(self.issues.item(i).text().startswith("Ostrzeżenie:") for i in range(self.issues.count()))
  self.status_label.setText(f"Warstwa {self.name} | {len(self.p.layers[self.name].items)} produktów | {errors} błędów | {warnings} ostrzeżeń")
 def diag(self):QMessageBox.information(self,"Diagnostyka",info())
 def new(self):self.p=Project();self.name="A";self.path=None;self.refresh()
 def open(self):
  p,_=QFileDialog.getOpenFileName(self,"Otwórz","","JSON (*.json)")
  if p:self.p=load(p);self.path=Path(p);self.name=next(iter(self.p.layers));self.refresh()
 def save(self):
  if not self.path:return self.save_as()
  save(self.p,self.path)
 def save_as(self):
  p,_=QFileDialog.getSaveFileName(self,"Zapisz","projekt.json","JSON (*.json)")
  if p:self.path=Path(p);self.save()
