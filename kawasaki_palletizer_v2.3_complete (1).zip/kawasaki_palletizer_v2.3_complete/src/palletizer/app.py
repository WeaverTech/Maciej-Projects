import sys
from PySide6.QtWidgets import QApplication,QMessageBox
from .main_window import MainWindow
from .diagnostics import install
from .theme import STYLE
def main():
 app=QApplication(sys.argv);app.setStyle("Fusion");app.setStyleSheet(STYLE)
 def show(text,path):
  box=QMessageBox();box.setIcon(QMessageBox.Icon.Critical);box.setText("Wystąpił błąd. Szczegóły zapisano w logu.");box.setInformativeText(path);box.setDetailedText(text);box.exec()
 install(show);w=MainWindow();w.show();return app.exec()
