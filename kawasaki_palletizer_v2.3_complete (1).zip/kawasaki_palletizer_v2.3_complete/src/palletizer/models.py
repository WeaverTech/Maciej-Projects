from __future__ import annotations
import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
class Kind(str,Enum): BAG="worek"; BOX="karton"
class Corner(str,Enum): A="A"; B="B"; C="C"; D="D"
@dataclass
class Pallet:
 length:float=1200; width:float=800; base_corner:Corner=Corner.D; x_direction:str="prawo"; y_direction:str="gora"
@dataclass
class Product:
 kind:Kind=Kind.BAG; length:float=600; width:float=400; height:float=100; layer_increment:float=100; allow_overhang:bool=True; max_overhang:float=30; allow_overlap:bool=True; max_overlap:float=20
 def footprint(self,r): return (self.width,self.length) if r%180==90 else (self.length,self.width)
@dataclass
class Placement: id:int; x:float; y:float; rotation:int=0; order:int=1
@dataclass
class Layer: name:str; items:list[Placement]=field(default_factory=list)
@dataclass
class Robot:
 program_name:str="paletyzacja"; base_name:str="poczatekpal"; pickup:str="pobierz"; pickup_approach:str="pobierz_najazd"; layers:int=7; first_z:float=-100; safe_z:float=500; pick_mode:str="pojedynczy"; s1_name:str="Sekcja 1"; s1_on:str="12,-13"; s1_off:str="-12,13"; s2_name:str="Sekcja 2"; s2_on:str="10,-11"; s2_off:str="-10,11"; assignments:str="1=1,2=2;3=1,4=2;5=1,6=2"; grip_wait:float=.5; release_wait:float=.2
@dataclass
class Project:
 version:int=3; name:str="Nowy projekt"; pallet:Pallet=field(default_factory=Pallet); product:Product=field(default_factory=Product); layers:dict[str,Layer]=field(default_factory=lambda:{"A":Layer("A")}); sequence:list[str]=field(default_factory=lambda:["A"]); robot:Robot=field(default_factory=Robot)
 def to_dict(self):
  d=asdict(self);d["pallet"]["base_corner"]=self.pallet.base_corner.value;d["product"]["kind"]=self.product.kind.value;return d
 @classmethod
 def from_dict(cls,d):
  p=dict(d["pallet"]);p["base_corner"]=Corner(p["base_corner"]);q=dict(d["product"]);q["kind"]=Kind(q["kind"]);ls={k:Layer(v.get("name",k),[Placement(**x) for x in v.get("items",[])]) for k,v in d["layers"].items()};return cls(d.get("version",3),d.get("name","Projekt"),Pallet(**p),Product(**q),ls,d.get("sequence",["A"]),Robot(**d.get("robot",{})))
def save(p,path):Path(path).write_text(json.dumps(p.to_dict(),ensure_ascii=False,indent=2),encoding="utf-8")
def load(path):return Project.from_dict(json.loads(Path(path).read_text(encoding="utf-8")))
