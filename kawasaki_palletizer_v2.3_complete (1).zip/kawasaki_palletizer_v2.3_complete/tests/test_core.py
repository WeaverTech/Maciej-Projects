from palletizer.models import *
from palletizer.core import *
def sample():
 p=Project();p.layers["A"].items=[Placement(i,i*100,200,0,i) for i in range(1,7)];return p
def test_single():assert render_as(sample()).count("JMOVE pobierz_najazd")==6
def test_double():
 p=sample();p.robot.pick_mode="podwojny";assert not parse_cycles(p.robot.assignments,[1,2,3,4,5,6])[1]
def test_axes():
 p=Project();p.pallet.base_corner=Corner.D;p.pallet.x_direction="prawo";p.pallet.y_direction="gora";assert transform(100,600,p)==(100,200)
def test_invalid_axes():
 p=Project();p.pallet.x_direction="prawo";p.pallet.y_direction="lewo";assert not axes_valid(p)
def test_rotate_compare():
 p=Project();p.layers["A"].items=[Placement(1,300,200,0,1)];rotate_b(p);assert compare_ab(p)[0][0]=="Informacja"
def test_as_validator():assert validate_as("FOR x=1 TO 2\nEND")==[]
