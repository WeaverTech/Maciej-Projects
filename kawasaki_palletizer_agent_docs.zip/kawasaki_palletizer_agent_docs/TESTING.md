# Testowanie

## Polecenia
```powershell
$env:PYTHONPATH = "src"
python -m compileall -q src tests run.py
pytest -q
```

## Minimalne testy rdzenia
- transformacje każdego narożnika BASE,
- wszystkie dozwolone kierunki osi,
- odrzucenie osi równoległych,
- obrót A do B,
- obrys produktu po obrocie 90°,
- wystawanie w granicy i poza limitem,
- nakładanie w granicy i poza limitem,
- Z warstw i przekładek,
- zapis/odczyt JSON,
- chwyt pojedynczy,
- chwyt podwójny,
- brakujące i powtórzone produkty w cyklach,
- eksport AS.

## Testy GUI
- start głównego okna offscreen,
- każdy przycisk paska,
- generator otwiera się w dużym oknie,
- okno cykli otwiera się,
- dodaj/obróć/przesuń/usuń,
- Delete i Backspace,
- wejście do Walidacji odświeża stan,
- tryb pojedynczy blokuje pola sekcji 2,
- miarka P1/P2/Esc/PPM,
- podgląd AS i kopiowanie,
- zapis i odczyt projektu.

## Test ręczny przed wydaniem
Uruchomić aplikację na Windows 11, Python 3.12, ekran 1920×1080 przy skalowaniu 100% oraz 150%.
