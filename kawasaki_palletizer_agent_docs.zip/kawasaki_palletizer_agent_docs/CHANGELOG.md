# Historia funkcjonalna

## 2.3
- walidacja po wejściu w zakładkę,
- graficzna miarka P1/P2 z instrukcją w pasku stanu,
- dynamiczne wyłączanie drugiej sekcji chwytaka,
- narożniki A/B/C/D oraz oznaczenie BASE,
- wybór kierunków +X/+Y,
- uproszczony pasek narzędzi.

## 2.2
- testy GUI i diagnostyka,
- walidator AS,
- porównanie A/B,
- testowa transformacja punktu,
- inteligentne przyciąganie.

## 2.1
- nowoczesny jasny styl,
- walidacja ciągła,
- większy generator.

## 2.0
- pakiet funkcji edytora, chwytaka, generatora i eksportu AS.
