# Specyfikacja produktu

## Użytkownik docelowy
Inżynier lub programista robotów Kawasaki przygotowujący paletyzację worków albo kartonów. Aplikacja ma umożliwiać szybkie ułożenie warstwy, sprawdzenie współrzędnych i przygotowanie kodu AS do dalszej weryfikacji w neoROset lub na kontrolerze.

## Przepływ użytkownika
1. Utwórz projekt.
2. Wpisz fizyczne wymiary palety.
3. Wybierz narożnik BASE oraz kierunki +X i +Y.
4. Wybierz worek lub karton i wprowadź wymiary.
5. Utwórz warstwę A ręcznie lub generatorem.
6. Ustaw pozycje środków, obroty 0/90/180/270 i kolejność.
7. Opcjonalnie utwórz B przez obrót A o 180°.
8. Wybierz chwyt pojedynczy lub podwójny.
9. Ustaw sygnały sekcji chwytaka.
10. Otwórz Walidację.
11. Sprawdź punkt i osie.
12. Otwórz podgląd AS, skopiuj lub zapisz kod.

## Geometria
- Paleta jest prostokątem o fizycznych wymiarach długości i szerokości.
- Produkt jest prostokątnym obrysem 2D pozycjonowanym środkiem.
- Karton nie powinien wystawać ani nakładać się na inne kartony.
- Dla worka można dopuścić kontrolowane wystawanie i nakładanie w milimetrach.
- Obrót 90° zamienia długość i szerokość obrysu.

## Warstwy
- Szablony: A, B i potencjalnie kolejne.
- Typowa sekwencja: A/B/A/B.
- Kolejność produktów jest wspólna dla danego szablonu.
- B domyślnie powstaje przez obrót A o 180° wokół środka palety.

## Z i przekładki
- `first_z`: lokalne Z punktów pierwszej warstwy.
- `layer_increment`: przyrost kolejnych warstw.
- `safe_z`: bezpieczna wysokość ponad aktualną warstwą.
- Przekładka jest opcjonalna i wpływa na wysokość, ale nie ma pełnej trajektorii pobrania.

## Chwytak
### Pojedynczy
Jeden produkt na cykl. Używana sekcja 1.

### Podwójny
Dwa produkty mogą być pobrane podczas jednego dojazdu do pobrania. Każdy produkt musi mieć przypisaną odrębną sekcję. Przykład:
`1=1,2=2;3=1,4=2;5=1,6=2`

## Walidacja
- wyjście poza paletę,
- nakładanie produktów,
- limity worków,
- nieciągła kolejność,
- błędne osie,
- brak produktów,
- błędne cykle chwytaka,
- brak sygnałów,
- niespójność A/B,
- podstawowa walidacja struktury kodu AS.
