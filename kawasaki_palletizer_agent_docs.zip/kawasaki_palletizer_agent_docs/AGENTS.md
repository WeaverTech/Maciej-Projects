# Instrukcja dla agentów AI i programistów

## Cel
Kawasaki Palletizer to lokalna aplikacja desktopowa w Pythonie i PySide6 do projektowania paletyzacji worków i kartonów oraz generowania kodu Kawasaki AS. Interfejs jest po polsku. Użytkownik projektuje geometrię względem fizycznej palety, wybiera narożnik BASE i kierunki osi, definiuje warstwy A/B oraz konfigurację chwytaka jedno- lub dwusekcyjnego.

## Najważniejsze zasady domenowe
1. Pozycja produktu w edytorze oznacza środek prostokątnego obrysu produktu.
2. BASE znajduje się w wybranym narożniku górnej powierzchni palety.
3. Geometria warstwy jest niezależna od formatu Kawasaki AS.
4. Warstwa B może być obrotem warstwy A o 180° względem środka palety.
5. W trybie pojedynczym każdy produkt ma osobny cykl pobrania i używa sekcji chwytaka 1.
6. W trybie podwójnym dwa produkty mogą być pobrane jednocześnie, lecz każdy musi mieć inną sekcję chwytaka.
7. Kod AS jest szablonem stanowiskowym. Nie wolno zakładać, że można go uruchomić bez weryfikacji BASE, TCP, orientacji, sygnałów, limitów oraz trajektorii.
8. Nie zmieniaj konwencji narożników bez migracji plików projektu:
   - A: lewy górny,
   - B: prawy górny,
   - C: prawy dolny,
   - D: lewy dolny.

## Priorytety zmian
1. Stabilność i testy regresyjne GUI.
2. Prawidłowość transformacji i kodu AS.
3. Czytelna walidacja.
4. Ergonomia edytora 2D.
5. Dopiero później nowe funkcje automatyczne.

## Reguły implementacyjne
- Logika modeli, geometrii i eksportu nie może być implementowana bezpośrednio w obsłudze przycisków.
- Wszystkie wartości geometrii są przechowywane w milimetrach.
- Do porównań geometrii używaj tolerancji, nigdy `value > 0` bez EPS.
- Zmiana narożnika BASE lub osi nie może fizycznie przesuwać produktów na planszy. Zmienia tylko transformację wyjściową.
- Każda nowa funkcja GUI wymaga testu otwarcia i podstawowej interakcji w pytest-qt.
- Każdy błąd nieobsłużony ma trafiać do logu użytkownika.
- Nie usuwaj zgodności zapisu JSON bez wersjonowania i migracji.

## Kryteria ukończenia zmiany
- `python -m compileall -q src tests run.py` przechodzi.
- `pytest -q` przechodzi.
- Główne okno otwiera się w trybie offscreen.
- Generator, edytor cykli i podgląd AS otwierają się bez wyjątku.
- Dodanie, obrót, przeciąganie, usunięcie i zapis projektu działają.
- Walidacja nie pokazuje błędów `0.0 mm` wynikających z szumu zmiennoprzecinkowego.
- Eksport AS jest sprawdzony na przykładzie trybu pojedynczego i podwójnego.

## Znane ryzyka
- Składnia i dostępne instrukcje AS mogą różnić się między kontrolerami Kawasaki.
- Składanie orientacji O/A/T nie powinno być upraszczane do dowolnego dodawania kąta do jednej składowej.
- Produkty typu worek są uproszczone do prostokątnego obrysu 2D.
- Walidacja 2D nie zastępuje analizy kolizji robota i chwytaka.
