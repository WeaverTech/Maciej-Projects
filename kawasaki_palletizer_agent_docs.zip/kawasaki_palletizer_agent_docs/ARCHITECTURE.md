# Architektura

## Stos
- Python 3.11 lub 3.12
- PySide6 / Qt 6
- pytest
- pytest-qt
- JSON jako format projektu

## Warstwy logiczne
### Modele
Paleta, produkt, pozycja, szablon warstwy, robot, konfiguracja chwytaka i projekt.

### Geometria
Transformacja współrzędnych, obrysy, kolizje 2D, wystawanie, obrót warstw i generator układów.

### Chwytak
Parsowanie cykli, walidacja sekcji i przypisanie produktów.

### Eksport AS
Generowanie punktów A/B, pętli warstw, przesunięcia Z, bezpiecznych najazdów i sygnałów chwytaka.

### GUI
Główne okno, scena 2D, formularze ustawień, generator, edytor cykli, walidacja, miarka i podgląd AS.

### Diagnostyka
Globalny wyjątek, log aplikacji, informacje o środowisku.

## Kierunek refaktoryzacji
Plik głównego okna nie powinien rosnąć bez końca. Kolejne wydanie powinno wydzielić:
- `widgets/pallet_view.py`,
- `dialogs/generator.py`,
- `dialogs/cycles.py`,
- `dialogs/as_preview.py`,
- `services/validation.py`,
- `services/project_history.py`,
- `exporters/kawasaki_as.py`.

## Przepływ danych
GUI aktualizuje Project. Widok 2D renderuje Project. Walidator czyta Project i zwraca problemy. Eksporter czyta Project i generuje tekst AS. GUI nie powinno być źródłem prawdy.
