# Start dla kolejnego agenta

Przeczytaj w kolejności:
1. `AGENTS.md`
2. `PROJECT_SPEC.md`
3. `ARCHITECTURE.md`
4. `AS_EXPORT_GUIDE.md`
5. `TESTING.md`
6. `ROADMAP.md`

Przed zmianą uruchom testy. Po zmianie dodaj test regresyjny. Nie uruchamiaj założeń domenowych na rzeczywistym robocie bez weryfikacji inżynierskiej.
