# Generator Kawasaki AS

## Założenie BASE
Punkt bazowy jest nauczony w wybranym narożniku górnej powierzchni palety. Punkty są generowane względem BASE:

`POINT wa_cel[1] = poczatekpal+TRANS(X,Y,Z,O,A,T)`

## Warstwy
Warstwa A i B mają osobne tablice punktów. W pętli wybierana jest właściwa tablica przez `.j MOD 2`.

## Wysokość
- `.z_offset = (.j-1)*.wyswarstwy`
- `.z_safe = safe_height+.z_offset`
- odkładanie: `SHIFT(cel[n] BY 0,0,.z_offset)`
- najazd: `SHIFT(cel[n] BY 0,0,.z_safe)`

## Sygnały chwytaka
Pole sygnału jest argumentem instrukcji SIGNAL, np. `12,-13` daje `SIGNAL 12,-13`.

### Pojedynczy
Pobranie, sekcja 1 ON, przejazd, odkładanie, sekcja 1 OFF.

### Podwójny
W jednym pobraniu włączane są obie przypisane sekcje. Przy każdym punkcie odkładania wyłączana jest wyłącznie sekcja przypisana do produktu.

## Weryfikacja przed robotem
- model i wersja kontrolera,
- składnia POINT/TRANS/SHIFT,
- orientacja BASE i TCP,
- znaki osi,
- sygnały fizyczne,
- `WEIGHT`,
- limity osi,
- JMOVE/LMOVE,
- wysokość bezpieczna,
- trajektoria bezkolizyjna.
