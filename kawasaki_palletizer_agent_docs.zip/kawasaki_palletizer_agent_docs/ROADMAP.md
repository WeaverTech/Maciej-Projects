# Roadmap

## Najbliższe
1. Refaktoryzacja głównego okna na mniejsze moduły.
2. Migrator starszych plików projektu.
3. Import punktów z kodu AS.
4. Import tabeli ze schowka/CSV.
5. Raport projektu PDF i PNG warstw.
6. Profile stanowisk Kawasaki.
7. Pełniejsza matematyka orientacji O/A/T.

## Później
- podgląd 3D stosu,
- analiza podparcia produktów między warstwami,
- zaawansowany packing mieszanego układu 0°/90°,
- eksport dla innych robotów jako oddzielne wtyczki,
- instalator Windows i podpisany EXE.
